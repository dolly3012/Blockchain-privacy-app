from flask import Flask, render_template, request, redirect, url_for, session, send_file
import datetime
import os
import json
import pickle
import pyaes
import pbkdf2
import sqlite3
import time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import mimetypes
import numpy as np
import smtplib
from email.message import EmailMessage
from datetime import datetime, timedelta
from io import BytesIO
from functools import wraps
import hashlib

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this-in-production-12345'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Global variables
runtime_data = []

# Create necessary folders
os.makedirs('uploads', exist_ok=True)
os.makedirs('ipfs_storage', exist_ok=True)

# Database initialization
def init_db():
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            usertype TEXT NOT NULL,
            email TEXT NOT NULL
        )
    ''')
    
    # Files table (replaces blockchain direct sharing)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner TEXT NOT NULL,
            filename TEXT NOT NULL,
            hashcode TEXT NOT NULL,
            access_users TEXT NOT NULL,
            upload_date TEXT NOT NULL
        )
    ''')
    
    # Time restrictions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS time_restrictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            start_date TEXT NOT NULL,
            end_date TEXT NOT NULL,
            owner TEXT NOT NULL,
            filename TEXT NOT NULL
        )
    ''')
    
    # Indirect access table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS indirectaccess (
            filename TEXT,
            ownername TEXT,
            username TEXT
        )
    ''')
    
    conn.commit()
    conn.close()

init_db()

# Authentication decorators
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def owner_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session or session.get('usertype') != 'Data Owner':
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def user_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session or session.get('usertype') not in ['Doctor', 'Researcher']:
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

# Encryption functions
def getKey():
    password = "s3cr3t*c0d3"
    passwordSalt = '76895'
    key = pbkdf2.PBKDF2(password, passwordSalt).read(32)
    return key

def to_datetime(datestring):
    return datetime.strptime(datestring, '%d-%b-%Y %H:%M:%S')

def encrypt(plaintext):
    aes = pyaes.AESModeOfOperationCTR(getKey(), pyaes.Counter(31129547035000047302952433967654195398124239844566322884172163637846056248223))
    ciphertext = aes.encrypt(plaintext)
    return ciphertext

def decrypt(enc):
    aes = pyaes.AESModeOfOperationCTR(getKey(), pyaes.Counter(31129547035000047302952433967654195398124239844566322884172163637846056248223))
    decrypted = aes.decrypt(enc)
    return decrypted

# File storage functions (replaces IPFS)
def save_encrypted_file(file_content):
    """Save encrypted file and return hash"""
    encrypted = encrypt(file_content)
    pickled = pickle.dumps(encrypted)
    
    # Generate hash for the file
    file_hash = hashlib.sha256(pickled).hexdigest()
    
    # Save to local storage
    filepath = os.path.join('ipfs_storage', file_hash)
    with open(filepath, 'wb') as f:
        f.write(pickled)
    
    return file_hash

def load_encrypted_file(file_hash):
    """Load and decrypt file from hash"""
    filepath = os.path.join('ipfs_storage', file_hash)
    with open(filepath, 'rb') as f:
        pickled = f.read()
    
    encrypted = pickle.loads(pickled)
    decrypted = decrypt(encrypted)
    return decrypted

# Routes
@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html', data='')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('t1')
        password = request.form.get('t2')
        usertype = request.form.get('t3')
        
        conn = sqlite3.connect("db.sqlite3")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username=? AND password=? AND usertype=?", 
                      (username, password, usertype))
        user = cursor.fetchone()
        conn.close()
        
        if user:
            session['username'] = username
            session['usertype'] = usertype
            session['access_user'] = usertype
            
            status = f"Welcome {username}"
            if usertype == 'Data Owner':
                return render_template('DataOwnerScreen.html', data=status)
            else:
                return render_template('DataUserScreen.html', data=status)
        else:
            return render_template('Login.html', data='Login failed. Invalid credentials.')
    
    return render_template('Login.html', data='')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('t1')
        password = request.form.get('t2')
        usertype = request.form.get('t3')
        email = request.form.get('t4')
        
        conn = sqlite3.connect("db.sqlite3")
        cursor = conn.cursor()
        
        try:
            cursor.execute("INSERT INTO users (username, password, usertype, email) VALUES (?, ?, ?, ?)",
                         (username, password, usertype, email))
            conn.commit()
            conn.close()
            return render_template('Signup.html', data="✅ Signup completed successfully! You can now login.")
        except sqlite3.IntegrityError:
            conn.close()
            return render_template('Signup.html', data=f"❌ Username '{username}' already exists")
    
    return render_template('Signup.html', data='')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/upload_image', methods=['GET', 'POST'])
@login_required
@owner_required
def upload_image():
    if request.method == 'POST':
        global runtime_data
        start = time.time()
        
        access = request.form.getlist('t2')
        access = ' '.join(access).strip()
        
        file = request.files.get('t1')
        if not file:
            return render_template('UploadImage.html', data='Please upload a file')
        
        filename = file.filename
        myfile = file.read()
        
        # Save encrypted file
        try:
            hashcode = save_encrypted_file(myfile)
        except Exception as e:
            return render_template('UploadImage.html', data=f'Error saving file: {str(e)}')
        
        now = datetime.now()
        current_time = now.strftime("%Y-%m-%d %H:%M:%S")
        username = session.get('username')
        
        # Save to database
        conn = sqlite3.connect("db.sqlite3")
        cursor = conn.cursor()
        cursor.execute("INSERT INTO files (owner, filename, hashcode, access_users, upload_date) VALUES (?, ?, ?, ?, ?)",
                      (username, filename, hashcode, access, current_time))
        conn.commit()
        conn.close()
        
        end = time.time()
        runtime_data.append(f"{filename},{end - start}")
        
        output = f'✅ File saved successfully with hash code:<br/><b>{hashcode}</b>'
        return render_template('UploadImage.html', data=output)
    
    return render_template('UploadImage.html', data='')

@app.route('/revoke_user', methods=['GET', 'POST'])
@login_required
@owner_required
def revoke_user():
    username = session.get('username')
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT filename FROM files WHERE owner=?", (username,))
    files = cursor.fetchall()
    conn.close()
    
    output = '<tr><td><font size="" color=black>Choose&nbsp;File&nbsp;To&nbsp;Revoke&nbsp;User</b></td>'
    output += '<td><select name="t1">'
    
    for file in files:
        output += f'<option value="{file[0]}">{file[0]}</option>'
    
    output += "</select></td></tr>"
    return render_template('RevokeUser.html', data=output)

@app.route('/revoke_user_action', methods=['POST'])
@login_required
@owner_required
def revoke_user_action():
    username = session.get('username')
    filename = request.form.get('t1')
    
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM files WHERE owner=? AND filename=?", (username, filename))
    conn.commit()
    conn.close()
    
    output = f'✅ All users revoked from file: {filename}'
    return render_template('DataOwnerScreen.html', data=output)

@app.route('/access_share_data')
@login_required
@user_required
def access_share_data():
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM files")
    files = cursor.fetchall()
    conn.close()
    
    if files:
        output = '<table border=1 align=center width=100%><tr><th><font size="" color="black">Data Owner Name</th>'
        output += '<th><font size="" color="black">Filename</th>'
        output += '<th><font size="" color="black">Hash Value</th>'
        output += '<th><font size="" color="black">Access Permission Users</th>'
        output += '<th><font size="" color="black">Upload Date Time</th>'
        output += '<th><font size="" color="black">Download & View Data</th></tr>'
        
        for file in files:
            file_id, owner, filename, hashcode, access_users, upload_date = file
            output += f'<tr><td><font size="" color="black">{owner}</td>'
            output += f'<td><font size="" color="black">{filename}</td>'
            output += f'<td><font size="" color="black">{hashcode[:16]}...</td>'
            output += f'<td><font size="" color="black">{access_users}</td>'
            output += f'<td><font size="" color="black">{upload_date}</td>'
            output += f'<td><a href="{url_for("download", t1=filename, t2=hashcode, t3=access_users)}"><font size="" color="black">Click Here</a></td>'
        
        return render_template('AccessShareData.html', data=output)
    else:
        return render_template('AccessShareData.html', data="No Files Shared")

@app.route('/download')
@login_required
@user_required
def download():
    filename = request.args.get('t1')
    hashcode = request.args.get('t2')
    useres = request.args.get('t3')
    access_user = session.get('access_user')
    username = session.get('username')
    
    if access_user not in useres:
        return render_template('AccessShareData.html', data="❌ You do not have access control for this file")
    
    # Check time restrictions
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    cursor.execute("SELECT start_date, end_date FROM time_restrictions WHERE username=? AND filename=?",
                  (username, filename))
    time_data = cursor.fetchone()
    conn.close()
    
    if time_data:
        sdate, cdate = time_data
        now = datetime.now()
        try:
            yesterday = to_datetime(str(sdate))
            tomorrow = to_datetime(str(cdate))
            
            if not (yesterday < now < tomorrow):
                return render_template('AccessShareData.html', data="❌ Time expired for this file")
        except:
            pass  # No time restrictions or invalid format
    
    # Load and decrypt file
    try:
        content = load_encrypted_file(hashcode)
        mime_type, _ = mimetypes.guess_type(filename)
        
        return send_file(
            BytesIO(content),
            mimetype=mime_type or 'application/octet-stream',
            as_attachment=True,
            download_name=filename
        )
    except Exception as e:
        return render_template('AccessShareData.html', data=f'❌ Error downloading file: {str(e)}')

@app.route('/indirect_access', methods=['GET', 'POST'])
@login_required
@user_required
def indirect_access():
    username = session.get('username')
    access_user = session.get('access_user')
    
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT filename FROM files WHERE access_users LIKE ?", (f'%{access_user}%',))
    files = cursor.fetchall()
    conn.close()
    
    output = '<tr><td><font size="" color=black>Choose&nbsp;File&nbsp;For&nbsp;Indirect&nbsp;Access</b></td>'
    output += '<td><select name="t1">'
    
    for file in files:
        output += f'<option value="{file[0]}">{file[0]}</option>'
    
    output += "</select></td></tr>"
    return render_template('IndirectAccess.html', data=output)

@app.route('/indirect_access_action', methods=['POST'])
@login_required
@user_required
def indirect_access_action():
    username = session.get('username')
    filename = request.form.get('t1')
    
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    
    # Get file info
    cursor.execute("SELECT owner, access_users FROM files WHERE filename=?", (filename,))
    file_data = cursor.fetchone()
    
    if file_data:
        owner, current_access = file_data
        new_access = current_access + " Doctor Researcher"
        
        # Update access
        cursor.execute("UPDATE files SET access_users=? WHERE filename=?", (new_access, filename))
        
        # Record indirect access
        cursor.execute("INSERT INTO indirectaccess VALUES (?, ?, ?)", (filename, owner, username))
        conn.commit()
        
        # Get owner email
        cursor.execute("SELECT email FROM users WHERE username=?", (owner,))
        email_data = cursor.fetchone()
        
        if email_data:
            email = email_data[0]
            # Send email notification
            try:
                msg = EmailMessage()
                msg.set_content(f"Indirect Access Given for your File {filename} By {username}")
                msg['Subject'] = 'Notification - Indirect Access Granted'
                msg['From'] = "evotingotp4@gmail.com"
                msg['to'] = email
                s = smtplib.SMTP('smtp.gmail.com', 587)
                s.starttls()
                s.login("evotingotp4@gmail.com", "xowpojqyiygprhgr")
                s.send_message(msg)
                s.quit()
            except Exception as e:
                print(f"Email error: {e}")
        
        output = f'✅ Indirect access given to other users for file: {filename}'
    else:
        output = '❌ File not found'
    
    conn.close()
    return render_template('DataUserScreen.html', data=output)

@app.route('/settime')
@login_required
@owner_required
def settime():
    username = session.get('username')
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT filename FROM files WHERE owner=?", (username,))
    files = cursor.fetchall()
    conn.close()
    
    output = '<table border=1 align=center width=100%><tr><th><font size="" color="black">Data Owner Name</th>'
    output += '<th><font size="" color="black">Filename</th>'
    output += '<th><font size="" color="black">Set Time</th>'
    
    for file in files:
        filename = file[0]
        output += f'<tr><td><font size="" color="black">{username}</td>'
        output += f'<td><font size="" color="black">{filename}</td>'
        output += f'<td><a href="{url_for("settimeuser", t1=username, t2=filename)}"><font size="" color="black">Click Here</a></td>'
    
    return render_template('DataOwnerScreen.html', data=output)

@app.route('/settimeuser')
@login_required
@owner_required
def settimeuser():
    filename = request.args.get('t2')
    ownername = request.args.get('t1')
    
    session['current_filename'] = filename
    
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    cursor.execute("SELECT username FROM users WHERE username!=? AND usertype!='Data Owner'", (ownername,))
    users = cursor.fetchall()
    conn.close()
    
    output = [user[0] for user in users]
    return render_template('settimeactionpage.html', data=output)

@app.route('/settimetouseraction', methods=['POST'])
@login_required
@owner_required
def settimetouseraction():
    username = session.get('username')
    filename = session.get('current_filename')
    user_nam = request.form.get('t1')
    sdate = request.form.get('sdate')
    cdate = request.form.get('cdate')
    
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    
    # Check if time already set
    cursor.execute("SELECT * FROM time_restrictions WHERE username=? AND filename=?", (user_nam, filename))
    existing = cursor.fetchone()
    
    if existing:
        output = f"❌ {user_nam} - Time already set for this user"
    else:
        cursor.execute("INSERT INTO time_restrictions (username, start_date, end_date, owner, filename) VALUES (?, ?, ?, ?, ?)",
                      (user_nam, sdate, cdate, username, filename))
        conn.commit()
        output = "✅ Set Time task completed. User time restrictions saved successfully!"
    
    conn.close()
    return render_template('settimepage.html', data=output)

@app.route('/viewnotification')
@login_required
@owner_required
def viewnotification():
    username = session.get('username')
    
    output = '<table border=1 align=center width=100%><tr><th><font size="" color="black">Data Owner Name</th>'
    output += '<th><font size="" color="black">Filename</th>'
    output += '<th><font size="" color="black">User Name</th>'
    
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM indirectaccess WHERE ownername=?", (username,))
    notifications = cursor.fetchall()
    conn.close()
    
    for row in notifications:
        filename, ownername, user = row
        output += f'<tr><td><font size="" color="black">{ownername}</td>'
        output += f'<td><font size="" color="black">{filename}</td>'
        output += f'<td><font size="" color="black">{user}</td>'
    
    return render_template('DataOwnerScreen.html', data=output)

@app.route('/graph')
@login_required
@user_required
def graph():
    global runtime_data
    
    if len(runtime_data) > 0:
        height = []
        bars = []
        
        for i in range(len(runtime_data)):
            arr = runtime_data[i].split(",")
            bars.append(arr[0][:15])  # Truncate long filenames
            height.append(float(arr[1]))
        
        y_pos = np.arange(len(bars))
        plt.figure(figsize=(10, 6))
        plt.bar(y_pos, height, color='steelblue')
        plt.xticks(y_pos, bars, rotation=45, ha='right')
        plt.title("Total Computation Time for Storage & Access Permission", fontsize=14, fontweight='bold')
        plt.ylabel("Time (seconds)")
        plt.xlabel("Files")
        plt.tight_layout()
        
        img = BytesIO()
        plt.savefig(img, format='png', dpi=100)
        img.seek(0)
        plt.close()
        
        return send_file(img, mimetype='image/png')
    
    return render_template('DataUserScreen.html', data="No computation data available yet. Upload some files first!")

if __name__ == '__main__':
    print("\n" + "="*70)
    print("🚀 AuthPrivacyChain Flask Application")
    print("="*70)
    print("✅ No Ganache Required")
    print("✅ No IPFS Required")
    print("✅ Everything runs locally with SQLite")
    print("="*70)
    print("\n📝 Access the application at: http://localhost:5000")
    print("\n💡 Quick Start:")
    print("   1. Go to http://localhost:5000")
    print("   2. Click 'Data User Signup Here'")
    print("   3. Create accounts (Data Owner, Doctor, Researcher)")
    print("   4. Login and start uploading/accessing files")
    print("\n" + "="*70 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)